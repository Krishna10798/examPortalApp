package com.eServer.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PostAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.eServer.config.JwtUtill;
import com.eServer.entity.JwtRequest;
import com.eServer.entity.JwtResponse;
import com.eServer.entity.User;
import com.eServer.service.impl.UserDetailsServiceImpl;

@RestController
//@CrossOrigin(origins = "http://localhost:4200")
@CrossOrigin("*")
public class AuthenticationController {
	@Autowired
	private AuthenticationManager authenticationManager;
	@Autowired
	private JwtUtill jwtutill;
	@Autowired
	private UserDetailsServiceImpl userDetailsServiceImpl;
	@Autowired
	private UserDetailsService userDetailsService;
	
	@PostMapping("/generate-token")
	public ResponseEntity<?> generateToken(@RequestBody JwtRequest jwtRequest) throws Exception{
		try {
			authenticate(jwtRequest.getUsername(), jwtRequest.getPassword());
		}catch(UsernameNotFoundException e){
			e.printStackTrace();
			throw new Exception("User not found");
			
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		UserDetails userDetails=this.userDetailsService.loadUserByUsername(jwtRequest.getUsername());
		String token = this.jwtutill.generateToken(userDetails);
		return ResponseEntity.ok(new JwtResponse(token));
	}
	
	private void authenticate(String username,String password) {
		try {
			authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username,password));
		}catch(DisabledException e) {
			System.out.println("User Disabled"+ e.getMessage());
			
	}catch(BadCredentialsException e) {
		System.out.println("Invalied credentionals"+e.getMessage());
		
	}
		
			catch (Exception e) {
				System.err.println("Error"+e.getMessage());

		}
		}
	@GetMapping("/current-user")
	public User getCurrentUser(Principal principal) {
		return (User)(this.userDetailsService.loadUserByUsername(principal.getName()));
	}
	}

