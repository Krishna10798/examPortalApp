package com.eServer.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eServer.entity.Role;

public interface RoleRepository extends JpaRepository<Role, Long> {

}
