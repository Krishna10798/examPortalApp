package com.eServer.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.eServer.dao.RoleRepository;
import com.eServer.dao.UserRepository;
import com.eServer.entity.User;
import com.eServer.entity.UserRole;
import com.eServer.service.UserService;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private RoleRepository roleRepository;

	private static List<User> list=new ArrayList<>();
	
	//creating user
	@Override
	public User createUser(User user, Set<UserRole> userRoles) throws Exception {
		
		User local=this.userRepository.findByUsername(user.getUsername());
		if(local!=null) {
			System.out.println("User is already present...");
			throw new Exception("user already present...");
		}else {
			//create user
			for(UserRole ur:userRoles) {
				roleRepository.save(ur.getRole());
			}
			user.getUserRole().addAll(userRoles);
			local =this.userRepository.save(user);
		}
		return local;
	}


	//get user by username
	@Override
	public User getUser(String username) {
		return this.userRepository.findByUsername(username);
	}

	//delete user by id
	@Override
	public void deleteUser(Long userId) {
		 this.userRepository.deleteById(userId);
	}


	//update user by username
	@Override
	public void updateUser(User user, Long userId) {
		list.stream().map(u->{
			if(u.getId()==userId) {
				u.setUsername(user.getUsername());
				u.setFirstName(user.getFirstName());
				u.setLastName(user.getLastName());
				u.setEmail(user.getEmail());
				u.setPassword(user.getPassword());
				u.setPhone(user.getPhone());
				u.setProfile(user.getProfile());
			}
			return u;
		}).collect(Collectors.toList());
		
	}

}
