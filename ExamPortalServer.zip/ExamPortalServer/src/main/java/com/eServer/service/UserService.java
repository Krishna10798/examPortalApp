package com.eServer.service;

import java.util.Set;

import com.eServer.entity.User;
import com.eServer.entity.UserRole;

public interface UserService {
	
	//creating user
	public User createUser(User user,Set<UserRole> userRoles) throws Exception;
	
	//get user by username
	public User getUser(String username);
	
	//delete user by id
	public void deleteUser(Long userId);
	
	//update user by username
	public void updateUser(User user,Long userId);

}
