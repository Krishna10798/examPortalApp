package com.eServer;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.eServer.entity.Role;
import com.eServer.entity.User;
import com.eServer.entity.UserRole;
import com.eServer.service.UserService;

@SpringBootApplication
public class ExamPortalServerApplication implements CommandLineRunner{
    
	@Autowired
	private UserService userService;
	
	public static void main(String[] args) {
		SpringApplication.run(ExamPortalServerApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		System.out.println("project is started.......");
//		
//		User user=new User();
//		user.setFirstName("krishna");
//		user.setLastName("yadav");
//		user.setUsername("KriyadaV");
//		user.setPassword("pqr");
//		user.setEmail("kri@gmail.com");
//		user.setProfile("demo.png");
//		user.setPhone("989898989");
//		
//		Role role_1=new Role();
//		role_1.setRoleId(100L);
//		role_1.setRoleName("ADMIN");
//		
//		
//		Set<UserRole> userRoleSet=new HashSet<>();
//		UserRole userRole=new UserRole();
//		userRole.setRole(role_1);
//		userRole.setUser(user);
//		userRoleSet.add(userRole);
//		
//		User user_1=this.userService.createUser(user, userRoleSet);
//		System.out.println(user_1.getUsername());
	}

}
