package com.eServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamPortalServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
